package ar.jornadas.data

import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext

class AgendaRepository(private val api: ProgramaApi, private val dao: CarteleraDao,
                       private val prefs: SharedPreferences) {
    val programa = dao.observar()

    val edicionDescargada = MutableStateFlow(prefs.getBoolean("edicion_descargada", false))

    suspend fun sincronizar() {
        val fichas = api.consultar().map {
            Charla(it.id, it.title, it.track, it.day, it.time, it.room, it.speaker, it.summary)
        }
        dao.sincronizar(fichas)
        withContext(Dispatchers.IO) { prefs.edit().putBoolean("edicion_descargada", true).commit() }
        edicionDescargada.value = true
    }

    suspend fun cambiarFavorita(id: String) = dao.alternar(id)
}
