package ar.jornadas.ui

import android.app.Application
import androidx.lifecycle.*
import ar.jornadas.Servicios
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.IOException

class ProgramaModel(app: Application) : AndroidViewModel(app) {
    private val servicios = Servicios.de(app)
    val mesa = servicios.mesa
    private val repo = servicios.agenda
    val charlas = repo.programa.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val fallo = MutableStateFlow(false)
    val cargando = MutableStateFlow(false)

    val hayEdicion = combine(repo.edicionDescargada, charlas) { marca, lista -> marca || lista.isNotEmpty() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, repo.edicionDescargada.value)

    fun cargarAlIniciar() {
        if (servicios.cargaAutomatica.compareAndSet(false, true)) recargar()
    }

    fun recargar() {
        if (!cargando.compareAndSet(false, true)) return
        viewModelScope.launch {
            fallo.value = false
            try {
                repo.sincronizar()
            } catch (e: IOException) {
                fallo.value = true
            } finally {
                cargando.value = false
            }
        }
    }

    fun marcar(id: String) { viewModelScope.launch { repo.cambiarFavorita(id) } }
}